const express = require('express');
const mysql = require('mysql2');
const app = express();

// Create MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'c237_ca'
});

connection.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL database');
});

// Set up view engine
app.set('view engine', 'ejs');
// enable static files
app.use(express.static('public'));
//enable form processing
app.use(express.urlencoded({
    extended: false
}));

// Define routes
app.get('/', (req, res) => {
    const sql = `SELECT * FROM tasks`;
    connection.query(sql, (error, results) => {
        if (error) {
            console.error(`Database query error:`, error.message);
            return res.status(500).send(`Error Retriving tasks`);
        }
        res.render(`index`, { tasks: results });
    });
});

app.get(`/task/:id`, (req, res) => {
    const taskId = req.params.id;
    const sql = `SELECT * FROM tasks WHERE taskId = ?`;

    connection.query(sql, [taskId], (error, results) => {
        if (error) {
            console.error(`Database query error:`, error.message);
            return res.status(500).send(`Error Retriving task by ID`);
        }

        if (results.length > 0) {
            res.render(`task`, { task: results[0] });
        } else {
            res.status(404).send(`task not found`);
        }
    });
});

app.get(`/addTask`, (req, res) => {
    res.render(`addTask`);
});

app.post(`/addTask`, (req, res) => {
    const { title, description, priority, status, due_date } = req.body;
    const sql = 'INSERT INTO tasks (title, description, priority, status, due_date) VALUES (?, ?, ?, ?, ?)';

    connection.query(sql, [title, description, priority, status, due_date], (error, results) => {
        if (error) {
            console.error("Error adding task", error);
            res.status(500).send(`Error adding task`);
        } else {
            res.redirect(`/`);
        }
    });
});

app.get(`/editTask/:id`, (req, res) => {
    const taskId = req.params.id;
    const sql = `SELECT * FROM tasks WHERE taskId = ?`;

    connection.query(sql, [taskId], (error, results) => {
        if (error) {
            console.error(`Database query error:`, error.message);
            return res.status(500).send(`Error Retriving task by ID`);
        }

        if (results.length > 0) {
            res.render(`editTask`, { task: results[0] });
        } else {
            res.status(404).send(`task not found`);
        }
    });
});

app.post(`/edittask/:id`, (req, res) => {
    const taskId = req.params.id;
    const { title, description, priority, status, due_date } = req.body;
    const sql = 'UPDATE tasks SET title = ?, description = ?, priority = ?, status = ?, due_date = ? WHERE taskId = ?';

    connection.query(sql, [title, description, priority, status, due_date, taskId], (error, results) => {
        if (error) {
            console.error("Error updating task", error);
            res.status(500).send(`Error updating task`);
        } else {
            res.redirect(`/`);
        }
    });
});

app.get(`/deletetask/:id`, (req, res) => {
    const taskId = req.params.id;
    const sql = `DELETE FROM tasks WHERE taskId = ?`;

    connection.query(sql, [taskId], (error, results) => {
        if (error) {
            console.error(`Error deleting task:`, error);
            return res.status(500).send(`Error deleting task`);
        } else {
            res.redirect(`/`);
        }
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () =>
    console.log(`Server is running at http://localhost:${PORT}`)
);
